package pk.edu.pucit.mobilecomputing.database;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import pk.edu.pucit.mobilecomputing.database.Database.DBHelper;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    DBHelper DB_Helper;
    EditText et_name, et_email, et_addr;
    ImageView img;
    Uri selectedImage;
    private static final String TAG = "MainActivity";
    int GET_FROM_GALLERY;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DB_Helper = new DBHelper(this);
        et_name = (EditText) findViewById(R.id.et_name);
        et_email = (EditText) findViewById(R.id.et_email);
        et_addr = (EditText) findViewById(R.id.et_address);
        img = (ImageView) findViewById(R.id.img);

    }

    /**
     * Displays the retrieved rows in a notification
     *
     * @param rows a String[] of rows from the cursor
     *             <p>
     *             <p>read more at<br/>
     *             https://developer.android.com/guide/topics/ui/notifiers/notifications.html<br/>
     *             https://www.tutorialspoint.com/android/android_notifications.htm
     *             https://www.gcflearnfree.org/androidbasics/managing-notifications-on-android/1/</p>
     */

    protected void show_notification(String[] rows, int count) {


        //NotificationManager is required for creating and displaying notifications
        NotificationManager manager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);


        NotificationCompat.Builder notify = new NotificationCompat.Builder(this)
                .setContentTitle("Records retrieved :: " + count)
                .setSmallIcon(android.R.drawable.ic_dialog_map)
                .setColor(Color.BLUE)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), android.R.drawable.gallery_thumb))
                .setPriority(Notification.PRIORITY_HIGH)
                .setVibrate(new long[]{100, 200, 300, 200, 222, 233, 55, 499, 89, 254, 156, 213, 21, 321, 121, 300, 200, 222, 233, 55, 499, 89, 254, 156, 213, 21, 321, 121, 300, 200, 222, 233, 55, 499, 89, 254, 156, 213, 21, 321, 121, 254, 25, 400, 300, 200, 10})
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALL))
                .setLights(Color.RED, 300, 700)
                .setAutoCancel(true);

        //style for displaying data
        NotificationCompat.InboxStyle is = new NotificationCompat.InboxStyle()
                .setBigContentTitle("Total Data: " + count);
        for (int i = 0; i < rows.length; i++) {
            is.addLine(rows[i]);
        }
        is.setSummaryText("All the data is now displayed in this notification");
        notify.setStyle(is);



       /* if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    Globals.NOTIFICATION_CHANNEL_ID,
                    Globals.NOTIFICATION_CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(Globals.NOTIFICATION_CHANNEL_NAME);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});
            channel.enableLights(true);
            notify.setChannel(Globals.NOTIFICATION_CHANNEL_ID);
            manager.createNotificationChannel(channel);
        }*/


        manager.notify(Globals.NOTIFICATION_ID, notify.build());
//        Log.d(Globals.LOG_TAG, "Notification sent");
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //Detects request codes
        if(requestCode==GET_FROM_GALLERY && resultCode == Activity.RESULT_OK) {
            selectedImage = data.getData();
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                img.setImageURI(selectedImage);
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_reset:
                et_name.setText("");
                et_email.setText("");
                et_addr.setText("");
                break;
            case R.id.btn_upd:
                long rid2 = DB_Helper.update(et_name.getText().toString(), et_email.getText().toString(), et_addr.getText().toString());
                Toast.makeText(this,"Updated", Toast.LENGTH_LONG).show();
                break;
            case R.id.img:
                startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), GET_FROM_GALLERY);

                //Intent k = new Intent(this, show2.class);
               // startActivity(k);
                //finish();
                break;
            case R.id.btn_show:

                Intent i = new Intent(getApplicationContext(), show2.class);
                startActivity(i);
                break;

            case R.id.btn_del:
                long rid3 = DB_Helper.delete(et_name.getText().toString());
                Toast.makeText(this,"Deleted", Toast.LENGTH_LONG).show();
                break;
            case R.id.btn_save:
                try {
                    InputStream iStream =   getContentResolver().openInputStream(selectedImage);
                    byte[] image = getBytes(iStream);
                    long rid = DB_Helper.insert(et_name.getText().toString(), et_email.getText().toString(), et_addr.getText().toString(), image);
                    Toast.makeText(this,"Data Inserted", Toast.LENGTH_LONG).show();

                    /*Cursor b = DB_Helper.read(rid);
                    String[] rows = new String[b.getCount()];
                    while (b.moveToNext()) {
                        rows[b.getPosition()] = "ID: " + b.getInt(b.getColumnIndex(DBHelper.ID))
                                + "\n" + "NAME: " + b.getString(b.getColumnIndex(DBHelper.NAME));
                    }
//                Toast.makeText(this,rows,Toast.LENGTH_LONG).show();
                    show_notification(rows, b.getCount());
                    b.close();*/
                }
                catch (IOException ioe){
                    Log.e(TAG, "<saveImageInDB> Error : " + ioe.getLocalizedMessage());
                }

                break;
        }

    }
}

